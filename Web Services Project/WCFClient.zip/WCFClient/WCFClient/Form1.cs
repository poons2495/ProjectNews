﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WCFClient.MITService;

namespace WCFClient
{
    public partial class Form1 : Form
    {
        MITService.MITServiceClient client = new MITService.MITServiceClient();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int regNo))
            {
                label1.Text = "";
                // label1.Text = client.GetName(regNo);
                Subject[] subjects = client.GetMarks(regNo);

                foreach(Subject subject in subjects)
                {
                    label1.Text += subject.Marks + " ";
                }
            }
        }
    }
}
